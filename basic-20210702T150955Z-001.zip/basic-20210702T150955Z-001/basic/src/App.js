import React, { useEffect } from "react";
import "./app.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Navbar from "./component/Navbar";
import Routes from "./routing/Routes";
import { Provider } from "react-redux";
import store from "./store";
import { setAuthToken } from "./utils/setAuthToken";
import { USER_LOGIN_FAIL } from "./redux/actions/types";
import { loadUserData } from "./redux/actions/user";

const App = () => {
  useEffect(() => {
    if (localStorage.usertoken) {
      setAuthToken(localStorage.usertoken);
      store.dispatch(loadUserData());
    }

    window.addEventListener("storage", () => {
      if (!localStorage.admintoken) store.dispatch({ type: USER_LOGIN_FAIL });
    });
  }, []);

  return (
    <Provider store={store}>
      <Router>
        <Navbar />
        <Switch>
          <Route component={Routes} />
        </Switch>
      </Router>
    </Provider>
  );
};

export default App;
