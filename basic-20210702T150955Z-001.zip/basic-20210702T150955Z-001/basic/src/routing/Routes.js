import React from "react";
import { Route, Switch } from "react-router-dom";
import ForgotPassword from "../component/ForgotPassword";
import Login from "../component/Login";
import NewPassword from "../component/NewPassword";
import Register from "../component/SignUp";
import Home from "../pages/Home";
import PrivateRoute from "./PrivateRoute";

const Routes = () => {
  return (
    <Switch>
      <Route exact path="/register" component={Register} />
      <Route exact path="/login" component={Login} />
      <Route exact path="/newPassword" component={NewPassword} />
      <Route exact path="/forgotPassword" component={ForgotPassword} />
      <PrivateRoute exact path="/" component={Home} />
    </Switch>
  );
};

export default Routes;
