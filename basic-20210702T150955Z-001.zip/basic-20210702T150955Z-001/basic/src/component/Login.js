import React, { useState } from "react";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { userLogin } from "../redux/actions/user";
import { Link } from "react-router-dom";
import "./style.css";
import signinLogo from "../assets/login.svg";
const Login = ({ userLogin, isAuthenticated, errors }) => {
  const [formData, setFormData] = useState({
    email: "test1@gmail.com",
    password: "test@1234",
  });
  const { email, password } = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    userLogin(email, password);
  };

  if (isAuthenticated) {
    return <Redirect to="/" />;
  }
  return (
    <section className="sign-in">
      <div className="container">
        <div className="signin-content">
          <div className="signin-image">
            <figure>
              <img src={signinLogo} alt="sing up image" className="loginImg" />
            </figure>
            <Link to="/register" className="signup-image-link">
              Create an account
            </Link>
          </div>
          <div className="signin-form">
            <h2 className="form-title">Sign In</h2>
            <form onSubmit={onSubmit} className="register-form" id="login-form">
              <div className="form-group">
                <label for="your_name">
                  <i className="fas fa-envelope"></i>
                </label>
                <input
                  email="text"
                  name="email"
                  id="your_name"
                  value={email}
                  onChange={onChange}
                  placeholder="Your Name"
                />
              </div>
              <div className="form-group">
                <label for="your_pass">
                  <i className="fas fa-key"></i>
                </label>
                <input
                  type="password"
                  name="password"
                  id="your_pass"
                  value={password}
                  onChange={onChange}
                  placeholder="Password"
                />
              </div>
              <div className="form-group">
                <Link to="/forgotPassword" className="signup-image-link">
                  Frogot Password ?
                </Link>
              </div>
              <div className="form-group">
                <h7>{errors}</h7>
              </div>
              <div className="form-group form-button">
                <button id="signin" className="form-submit" value="Log in">
                  Login
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
Login.propTypes = {
  userLogin: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.user.isAuthenticated,
  errors: state.user.errors,
});

export default connect(mapStateToProps, { userLogin })(Login);
