import React, { useState } from "react";
import axios from "../api/axios";
import { Redirect } from "react-router-dom";
import "./style.css";

const NewPassword = () => {
  const [errors, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    token: "",
    password: "",
  });

  const { token, password } = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const updatePassword = async (event) => {
    event.preventDefault();
    try {
      const { data } = await axios.post("/user/password/newPassword", formData);
      setError("");
      setSuccess(true);
      console.log(data);
    } catch (err) {
      if (err.response) {
        setError(err.response.data.error);
      }
    }
  };
  if (success) {
    alert("Password Successfully Changed");
    return <Redirect to="/login" />;
  }
  return (
    <div className="container forgetPassword-C">
      <div className="forgetPassword">
        <form>
          <div className="form-group forgotPassword">
            <label for="your_name">
              <i className="fas fa-envelope"></i>
            </label>
            <input
              email="text"
              name="token"
              value={token}
              onChange={onChange}
              id="your_name"
              placeholder="Paste Your Token Here"
            />
          </div>
          <div className="form-group">
            <label for="your_pass">
              <i className="fas fa-key"></i>
            </label>
            <input
              type="password"
              name="password"
              id="your_pass"
              value={password}
              onChange={onChange}
              placeholder="New Password"
            />
          </div>
          <h7>{errors}</h7>
          <div className="form-group form-button">
            <button
              type="submit"
              onClick={updatePassword}
              className="btn btn-primary proceed"
            >
              Update Password
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewPassword;
