import React, { useState } from "react";
import axios from "../api/axios";
import { Link } from "react-router-dom";
import "./style.css";
const ForgotPassword = () => {
  const [errors, setError] = useState("");
  const [token, setToken] = useState("");

  const [formData, setFormData] = useState({
    email: "",
  });

  const { email } = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const proceedPassword = async (event) => {
    event.preventDefault();
    try {
      const { data } = await axios.post(
        "/user/password/resetPassword",
        formData
      );
      setError("")
      setToken(data);
      console.log(data);
    } catch (err) {
      if (err.response) {
        setError(err.response.data.error);
      }
    }
  };

  return (
    <div className="container forgetPassword-C">
      <div className="forgetPassword">
        <form>
          <div className="form-group forgotPassword">
            <label for="your_name">
              <i className="fas fa-envelope"></i>
            </label>
            <input
              email="text"
              name="email"
              value={email}
              onChange={onChange}
              id="your_name"
              placeholder="Your Email"
            />
          </div>
          <h7>{errors}</h7>
          {token ? (
            <>
              <h6>Please Copy this Token: {token}</h6> and{" "}
              <Link to="/newPassword" className="forgotP">Click Here</Link>
            </>
          ) : (
            ""
          )}
          <div className="form-group form-button">
            <button
              type="submit"
              onClick={proceedPassword}
              className="btn btn-primary proceed"
            >
              Proceed
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ForgotPassword;
