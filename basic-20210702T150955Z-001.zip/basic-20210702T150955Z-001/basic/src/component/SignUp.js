import React, { useState } from "react";
import "./style.css";
import signupLogo from "../assets/signup.svg";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { userRegister } from "../redux/actions/user";

const SignUp = ({ userRegister, signupStatus, errors }) => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
  });

  const { name, email, password } = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    console.log(JSON.stringify(formData));
    userRegister(name, email, password);
  };

  if (signupStatus) {
    return <Redirect to="/login" />;
  }
  return (
    <section className="signup">
      <div className="container">
        <div className="signup-content">
          <div className="signup-form">
            <h2 className="form-title">Sign up</h2>
            <form
              onSubmit={onSubmit}
              className="register-form"
              id="register-form"
            >
              <div className="form-group">
                <label for="name">
                  <i className="fas fa-user"></i>
                </label>
                <input
                  type="text"
                  name="name"
                  value={name}
                  onChange={onChange}
                  id="name"
                  placeholder="Your Name"
                />
              </div>
              <div className="form-group">
                <label for="email">
                  <i className="fas fa-envelope"></i>
                </label>
                <input
                  type="email"
                  name="email"
                  value={email}
                  onChange={onChange}
                  id="email"
                  placeholder="Your Email"
                />
              </div>
              <div className="form-group">
                <label for="pass">
                  <i className="fas fa-key"></i>
                </label>
                <input
                  type="password"
                  name="password"
                  value={password}
                  onChange={onChange}
                  id="pass"
                  placeholder="Password"
                />
              </div>
              <div className="form-group">
                <h7>{errors}</h7>
              </div>
              <div className="form-group form-button">
                <button id="signup" className="form-submit" value="Register">
                  Register
                </button>
              </div>
            </form>
          </div>
          <div className="signup-image">
            <figure>
              <img src={signupLogo} alt="sing up image" className="loginImg" />
            </figure>
          </div>
        </div>
      </div>
    </section>
  );
};
SignUp.propTypes = {
  userRegister: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  signupStatus: state.user.signupStatus,
  errors: state.user.errors,
});

export default connect(mapStateToProps, { userRegister })(SignUp);
