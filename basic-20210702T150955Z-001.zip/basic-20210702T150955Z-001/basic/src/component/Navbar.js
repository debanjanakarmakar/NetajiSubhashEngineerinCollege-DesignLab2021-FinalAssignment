import React from "react";
import "./navbar.css";
import { Link } from "react-router-dom";
import { logout } from "../redux/actions/user";
import PropTypes from "prop-types";
import { connect } from "react-redux";
const Navbar = ({ logout, isAuthenticated, user: { user } }) => {
  return (
    <div>
      <nav className="navbar navbar-expand-sm bg-primary navbar-dark">
        <ul className="navbar-nav">
          {isAuthenticated ? (
            <>
              <li className="nav-item">
                <Link className="nav-link" href="https://www.facebook.com">
                  {user ? user.name : ""}
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" href="https://www.facebook.com">
                  About
                </Link>
              </li>
              <li className="nav-item">
                <p className="nav-link" onClick={logout}>
                  Logout
                </p>
              </li>
            </>
          ) : (
            <>
              <li className="nav-item">
                <Link className="nav-link" to="/login">
                  Login
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/register">
                  Register
                </Link>
              </li>
            </>
          )}
        </ul>
      </nav>
    </div>
  );
};
Navbar.propTypes = {
  logout: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.user.isAuthenticated,
  user: state.user,
});

export default connect(mapStateToProps, { logout })(Navbar);
